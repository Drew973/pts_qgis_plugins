# -*- coding: utf-8 -*-
"""
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import os

from PyQt5 import QtGui, QtWidgets, uic
from PyQt5.QtCore import pyqtSignal,QDate,QUrl

from PyQt5.QtWidgets import QComboBox,QLineEdit
from qgis.PyQt.QtWidgets import QFileDialog

from . import widget_value,layer_functions,file_dialogs

from qgis.utils import iface

import csv
import collections
from qgis.core import QgsFeatureRequest



def fixHeaders(path):
    with open(path) as f:
        t=f.read()
    r={'qgsfieldcombobox.h':'qgis.gui','qgsmaplayercombobox.h':'qgis.gui'}
    for i in r:
        t=t.replace(i,r[i])
    with open(path, "w") as f:
        f.write(t)


ui_path=os.path.join(os.path.dirname(__file__), 'ssir_generator_dockwidget_base.ui')
fixHeaders(ui_path)
FORM_CLASS, _ = uic.loadUiType(ui_path)


class ssir_generatorDockWidget(QtWidgets.QDockWidget, FORM_CLASS):

    closingPlugin = pyqtSignal()

    def __init__(self, parent=None):
        super(ssir_generatorDockWidget, self).__init__(parent)


        self.site=None
    
        self.setupUi(self)
        self.from_selected_button.clicked.connect(self.from_selected)

        self.save_button.clicked.connect(self.save)

        self.clear_button.clicked.connect(self.clear)
        
        self.init_key()
        self.help_button.clicked.connect(self.open_help)
        
        #special handling for comboboxes
        for k,v in self.key.items():
            if isinstance(v['widget'],QComboBox):
                v['widget'].setLineEdit(QLineEdit())

                        
        self.rules = (('Surveyed', 'not "csv" is null', 'green', None),('Unsurveyed', '"csv" is null', 'red', None))#rules for symbology
        self.split_button.clicked.connect(lambda:layer_functions.set_rules(self.layer_box.currentLayer(),self.rules))#change symbology
        self.layer_box.layerChanged.connect(self.layer_changed)

        self.layer_changed(self.layer_box.currentLayer())
        self.zoom_button.clicked.connect(self.zoom)

        self.site_box.valueChanged.connect(self.site_box_changed)
        
        self.layer_changed(self.layer_box.currentLayer())


  #create ordered dict self.key to link name of attribute to widget and default value
    def init_key(self):
        #site details
        self.key=collections.OrderedDict()
        self.key['site']={'widget':self.site_box,'default':''}
        self.key['section']={'widget':self.section,'default':''}
        self.key['start_ch']={'widget':self.start_ch,'default':0}
        self.key['end_ch']={'widget':self.end_ch,'default':0}
        self.key['section_length']={'widget':self.section_length,'default':0}
        self.key['assesment_length']={'widget':self.assesment_length,'default':0}

        #survey details
        self.key['surveyor']={'widget':self.surveyor,'default':''}
        self.key['survey_date']={'widget':self.survey_date,'default':QDate.currentDate().toString(widget_value.DATE_FORMAT)}
        self.key['photo_ref']={'widget':self.photo_ref,'default':''}
        self.key['additional_photos']={'widget':self.additional_photos,'default':''}

        #visual assesment
        self.key['surface_type']={'widget':self.surface_type,'default':'TSSC'}
        self.key['aggregate_size']={'widget':self.aggregate_size,'default':''}
        self.key['aggregate_condition']={'widget':self.aggregate_condition,'default':'Good'}
        self.key['inconsistencies']={'widget':self.inconsistencies,'default':'No'}
        self.key['contaminants']={'widget':self.contaminants,'default':'Na'}
        self.key['local_defects']={'widget':self.local_defects,'default':'Na'}
        self.key['drainage_adequate']={'widget':self.drainage_adequate,'default':'Yes'}

        #road layout
        self.key['meets_design_specification']={'widget':self.meets_design_specification,'default':'Yes'}
        self.key['appropriate_for_vunerable_users']={'widget':self.appropriate_for_vunerable_users,'default':'Yes'}
        self.key['appropriate_for_turning']={'widget':self.appropriate_for_turning,'default':'Yes'}

        #markings,signs,visibitity
        self.key['markings_clear']={'widget':self.markings_clear,'default':'Yes'}
        self.key['roadside_objects']={'widget':self.roadside_objects,'default':'Yes'}
        self.key['clear_sight_lines']={'widget':self.clear_sight_lines,'default':'Yes'}
        self.key['additional_comments']={'widget':self.additional_comments,'default':'Na'}

        #recomendation
        self.key['treatment_req']={'widget':self.treatment_req,'default':'Yes'}
        self.key['treatment_type']={'widget':self.treatment_type,'default':'Na'}
        self.key['change_il']={'widget':self.change_il,'default':'Yes'}
        self.key['other_action_req']={'widget':self.other_action_req,'default':'ROAD MARKING SURVEY'}
                


    def closeEvent(self, event):
        self.closingPlugin.emit()
        event.accept()
    


    def layer_changed(self,layer):

        if not layer:
            iface.messageBar().pushMessage('ssir generator:no layer')
            return
            
        field='segment_no'
        if layer_valid(layer):
        
            vals=self.valid_segments()
            self.site_box.setRange(min(vals),max(vals))
            self.site_box.setValue(vals[0])
            self.site_box_changed(self.site_box.value())#value in site_box might not change. site_box_changed might be called twice

        else:
            iface.messageBar().pushMessage('ssir generator:layer needs fields segment_no and csv')

            
    #change feature to red for unsurveyed,green for surveyed
   # def colour_feats(self) :
    ##    layer=iface.activeLayer()
     #   layer_functions.colour_features(self.surveyed_features(),layer,QtGui.QColor('green'))
     #   layer_functions.colour_features(self.unsurveyed_features(),layer,QtGui.QColor('red'))


    def save(self):
        p=file_dialogs.save_file_dialog(ext='.csv',caption='save as csv',default_name=str(self.segment_no()))
        
        if p:

            self.to_csv(p)
            iface.messageBar().pushMessage('ssir generator:saved to '+p)

            #setting 'csv' field of feature
            f=self.segment_no_to_feat()
            
            #self.colour_feats()
            self.layer_box.currentLayer()
            self.layer_box.currentLayer().startEditing()
            self.layer_box.currentLayer().changeAttributeValue(f.id(), self.layer_box.currentLayer().fields().indexOf('csv'),p)
            self.layer_box.currentLayer().commitChanges()



#int new_site
    def site_box_changed(self,new_site):

        if new_site in self.valid_segments():
            if new_site!=self.site:
               # self.change_segment(new_site)
                f=str(self.segment_no_to_feat(int(new_site))['csv'])
                self.site=new_site
                if os.path.exists(f):
                    self.load_csv(f)
                else:
                    self.clear()

        else:
            iface.messageBar().pushMessage('ssir generator:segment_no %d not in layer.'%(new_site))
            self.site_box.setValue(self.site)



    def valid_segments(self):
        if self.layer_box.currentLayer():
            return layer_functions.distinct_values(self.layer_box.currentLayer(),'segment_no')
        

#attributes to dict
    def to_dict(self):
        return {k:widget_value.get_value(v['widget']) for k,v in self.key.items()}


#opens help/index.html in default browser
    def open_help(self):
        help_path=os.path.join(os.path.dirname(__file__),'help','index.html')
        help_path='file:///'+os.path.abspath(help_path)
        QtGui.QDesktopServices.openUrl(QUrl(help_path))

        

    def from_selected(self):
        sf=self.layer_box.currentLayer().selectedFeatures()

        if len(sf)==0:
            iface.messageBar().pushMessage('ssir generator: no features selected')

        if len(sf)>1:
            iface.messageBar().pushMessage('ssir generator: more than 1 feature selected')

        if len(sf)==1:
            self.site_box.setValue(sf[0]['segment_no'])



#returns list of features with form in folder.
#needs folder to be set
    def surveyed_features(self):
        field='segment_no'
        return [f for f in self.layer_box.currentLayer().getFeatures() if os.path.exists(self.make_save_path(f[field]))]



#returns list of features without form in folder.
#needs folder to be set
    def unsurveyed_features(self):
        field='segment_no'
        return [f for f in self.layer_box.currentLayer().getFeatures() if not os.path.exists(self.make_save_path(f[field]))]




    def clear(self):
        #self.load_dict({k:self.key[k]['default'] for k in self.key})
        d={k:self.key[k]['default'] for k in self.key}
        f=self.segment_no_to_feat()

        d['site']=f['segment_no']
        d['section']=f['sec_label']
        d['start_ch']=f['st_ch']
        d['end_ch']=f['end_ch']
        d['section_length']=f['sec_len']
        d['assesment_length']=f['assess_len']

        self.load_dict(d)


    def load_csv(self,csv_file,sep=','):
        with open(csv_file,'r') as f:
            reader=csv.DictReader(f,fieldnames=['att','val'],dialect='excel',delimiter=sep)
            d={row['att']:row['val'] for row in reader}
            self.load_dict(d)                


                
    #load dict of attribute:val
    def load_dict(self,d):
        for k,v in self.key.items():
            widget_value.set_value(v['widget'],d[k],add=True)
            
            
    
    def to_csv(self,csv,sep=','):
        lines=['%s%s"%s"'%(k,sep,v) for k,v in self.to_dict().items()]#quote charactor around user given values-may contain ','

        with open(csv,'w') as f:
           # f.write('attribute%svalue\n'%(sep))#header
            f.write('\n'.join(lines))


    def segment_no(self):
        return self.site

        
    def segment_no_to_feat(self,segment_no=None):
        if not segment_no:
            segment_no=self.segment_no()
            
        field='segment_no'
        e='"%s"=%d'%(field,int(segment_no))
        request = QgsFeatureRequest().setFilterExpression(e)
        feats=[f for f in self.layer_box.currentLayer().getFeatures(request)]

        if len(feats)>1:
            raise KeyError('more than 1 feature with segment_no of '+str(segment_no))
        if len(feats)==0:
            raise KeyError('no features with segment_no of '+str(segment_no))

        return feats[0]
        

    def zoom(self):  
        self.layer_box.currentLayer().selectByIds([self.segment_no_to_feat().id()])#select segment
        layer_functions.zoom_to_selected(self.layer_box.currentLayer())


def layer_valid(layer):
    if layer.fields().indexOf('segment_no')==-1:
        return False
    
    if layer.fields().indexOf('csv')==-1:
        return False
    
    return True
    

def str_to_int(s):
    try:
        return int(s)
    except:
        return
